#!/bin/sh

server=$1
size=$2

cd RMIPing

java -Xms16m -Xmx512m -Djava.security.policy=security.policy -jar RMIPing.jar $server $size

cd ..
