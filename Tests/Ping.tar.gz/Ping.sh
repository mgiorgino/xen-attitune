#!/bin/sh

server=$1

cd Ping

java -jar Ping.jar $server

cd ..
